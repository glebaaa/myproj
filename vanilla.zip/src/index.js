var arr = {'apple': 800, 'banana': 602, 'milk': 707, 'cringe':228.8 };

function price(x){
 for (const [key, value] of Object.entries(x)) {
   x[key]+=x[key]*0.15;
   if(isInteger(x[key])==false){
     x[key] = Math.round(x[key]);
   }
  while(x[key]%5!= 0){
    x[key] += 1;
  }
}
 function isInteger(num) {
  return (num ^ 0) === num;
}
}


price(arr);

console.log(arr);